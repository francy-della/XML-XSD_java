package es_32_drone;

import java.util.Date;

/**
 *
 * @author FRANCESCADELLAMANO
 */

public class Posizione {
    private final double latitudine;
    private final double longitudine;
    private final long data_ora;
    private final double altitudine;
    
    public Posizione(Posizione posizione) {
        this.latitudine = posizione.latitudine;
        this.longitudine = posizione.longitudine;
        this.altitudine = posizione.altitudine;
        this.data_ora = posizione.data_ora;
    }
    
    public Posizione(double latitudine, double longitudine, double altitudine, long data_ora) {
        this.latitudine = latitudine;
        this.longitudine = longitudine;
        this.altitudine = altitudine;
        this.data_ora = data_ora;
    }

    public double getLatitudine() {
        return latitudine;
    }
    public double getLongitudine() {
        return longitudine;
    }
    public double getAltitudine() {
        return altitudine;
    }
    public long getDataOra() {
        return data_ora;
    }
    
    @Override
    public String toString() {
        return "Posizione ---> latitudine = " + latitudine + ", longitudine = " + longitudine + ", altitudine = " + altitudine + ", data e ora = " + new Date(data_ora) ;
    }
}
