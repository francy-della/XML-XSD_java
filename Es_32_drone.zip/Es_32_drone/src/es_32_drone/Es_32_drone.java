package es_32_drone;

import java.io.IOException;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author FRANCESCADELLAMANO
 */

public class Es_32_drone {
    public static void main(String[] args) {
        Parser parser = new Parser();
        List<Posizione> lista_pos = null;
        
        try {
            lista_pos = parser.parsingDoc(args[0]);
        } catch (ParserConfigurationException | SAXException exception) {
            System.err.println("ERRORE! parsing del file XML non riuscito.");
        } catch (IOException exception) {
            System.err.println("ERRORE! apertura del file XML non riuscita.");
        }
        
        for(Posizione pos : lista_pos)
        {
            System.out.println(pos);
        }
        
        System.out.println("\n-----------------------------------");
        System.out.println("LATITUDINE RAGGIUNTA DAL DRONE:");
        System.out.println("Minima: " + parser.getLatitudineMin());
        System.out.println("Massima: " + parser.getLatitudineMax());
        System.out.println("LONGITUDINE RAGGIUNTA DAL DRONE:");
        System.out.println("Minima: " + parser.getLongitudineMin());
        System.out.println("Massima: " + parser.getLongitudineMax());
        System.out.println("ALTITUDINE RAGGIUNTA DAL DRONE:");
        System.out.println("Minima: " + parser.getAltitudineMin());
        System.out.println("Massima: " + parser.getAltitudineMax());
        System.out.println("-----------------------------------");
    }        
}