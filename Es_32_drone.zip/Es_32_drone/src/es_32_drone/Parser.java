package es_32_drone;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 *
 * @author FRANCESCADELLAMANO
 */

public class Parser {
    private final List<Posizione> lista_pos;
     
    public Parser() {
        lista_pos = new ArrayList<Posizione>();
    }
    //EFFETTUA IL PARSING DEL FILE XML RICEVUTO
    public List<Posizione> parsingDoc(String file) throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory factory;
        DocumentBuilder builder;
        Document document;
        Element root, element;
        NodeList Nlist;
        //CREAZIONE DELL'ALBERO DOM
        factory = DocumentBuilderFactory.newInstance();
        builder = factory.newDocumentBuilder();
        document = builder.parse(file);
        root = document.getDocumentElement();
        //CREAZIONE DELLA LISTA CHE CONTERRA' LE VARIE POSIZIONI DEL DRONE
        Nlist = root.getElementsByTagName("posizione");
        if (Nlist != null && Nlist.getLength() > 0) {
            for (int i = 0; i < Nlist.getLength(); i++) {
                element = (Element) Nlist.item(i); 
                lista_pos.add(getPosizione(element));
            }
        }
        return lista_pos;
    }
    //RESTITUISCE LA POSIZIONE 
    private Posizione getPosizione(Element element) {
        Posizione pos;
        double latitudine = Double.parseDouble(getTesto(element, "latitudine"));
        double longitudine = Double.parseDouble(getTesto(element, "longitudine"));
        double altitudine = Double.parseDouble(getTesto(element, "altitudine"));
        Date data_ora = getData_Ora(element, "dataOra");
        pos = new Posizione(latitudine, longitudine, altitudine, data_ora.getTime());
        return pos;
    }
    //RESTITUISCE IL VALORE DI TESTO DELL'ELEMENTO RICEVUTO
    private String getTesto(Element element, String tag) {
        String value = null;
        NodeList Nlist;
        Nlist = element.getElementsByTagName(tag);
        if (Nlist != null && Nlist.getLength() > 0) {
            value = Nlist.item(0).getFirstChild().getNodeValue();
        }
        return value;
    }
    //RESTITUISCE LA DATA DELL'ELEMENTO RICEVUTO
    private Date getData_Ora(Element element, String tag) {
        Date date;
        try {
            date = DatatypeFactory.newInstance().newXMLGregorianCalendar(getTesto(element, tag)).toGregorianCalendar().getTime();
        } catch (DatatypeConfigurationException e) {
            date = null;
        }
        return date;
    }
    //RESTITUISCE LA LATITUDINE MINIMA (utilizza un for che scorre tutte le latitudini fino ad arrivare a quella più piccola)
    public double getLatitudineMin() {
        double latitudineMin = lista_pos.get(0).getLatitudine();
        for (Posizione pos : lista_pos) {
            if (pos.getLatitudine() < latitudineMin) {
                latitudineMin = pos.getLatitudine();
            }
        }
        return latitudineMin;
    }
    //RESTITUISCE LA LATITUDINE MASSIMA
    public double getLatitudineMax() {
        double latitudineMassima = lista_pos.get(0).getLatitudine();
        for (Posizione pos : lista_pos) {
            if (pos.getLatitudine() > latitudineMassima) {
                latitudineMassima = pos.getLatitudine();
            }
        }
        return latitudineMassima;
    }
    //RESTITUISCE LA LONGITUDINE MINIMA
    public double getLongitudineMin() {
        double longitudineMinima = lista_pos.get(0).getLongitudine();
        for (Posizione pos : lista_pos) {
            if (pos.getLongitudine() < longitudineMinima) {
                longitudineMinima = pos.getLongitudine();
            }
        }
        return longitudineMinima;
    }
    //RESTITUISCE LA LONGITUDINE MASSIMA
    public double getLongitudineMax() {
        double longitudineMassima = lista_pos.get(0).getLongitudine();
        for (Posizione pos : lista_pos) {
            if (pos.getLongitudine() > longitudineMassima) {
                longitudineMassima = pos.getLongitudine();
            }
        }
        return longitudineMassima;
    }
    //RESTITUISCE L'ALTITUDINE MINIMA
    public double getAltitudineMin() {
        double altitudineMin = lista_pos.get(0).getAltitudine();
        
        for (Posizione pos : lista_pos) {
            if (pos.getAltitudine() < altitudineMin) {
                altitudineMin = pos.getAltitudine();
            }
        }
        return altitudineMin;
    }
    //RESTITUISCE L'ALTITUDINE MASSIMA
    public double getAltitudineMax() {
        double altitudineMax = lista_pos.get(0).getAltitudine();
        
        for (Posizione pos : lista_pos) {
            if (pos.getAltitudine() > altitudineMax) {
                altitudineMax = pos.getAltitudine();
            }
        }
        return altitudineMax;
    }
}